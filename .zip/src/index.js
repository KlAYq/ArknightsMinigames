import React from "react";
import ReactDOM from "react-dom/client";
import App from "./app";
import { Provider } from "./components/ui/provider"

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <Provider defaultTheme="dark">
      <App />
    </Provider>
  </React.StrictMode>
);